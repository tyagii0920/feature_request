export class Feature {
    title: string;
    description: string;
    client: string;
    priority: number;
    targetDate: string;
    productArea: string;
}