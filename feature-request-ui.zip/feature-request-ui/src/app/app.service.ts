import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import * as moment from 'moment';
import { environment } from 'src/environments/environment';
import { Feature } from './feature.model';

@Injectable()
export class AppService {

    baseUrl: string = environment.backendUrl;

    constructor(private http: HttpClient) { }

    saveFeature(featureTitle: string,
        description: string,
        client: string,
        clientPriority: number,
        targetDate: Date,
        productArea: string) {
        let params: HttpParams = new HttpParams().set('title', featureTitle).set('description', description)
            .set('client', client).set('priority', clientPriority.toString()).set('targetDate', this.formatDate(targetDate)).set('productArea', productArea);
        let paramsStr: string = params.toString();
        return this.http.post(this.baseUrl + 'feature?' + paramsStr, null);
    }

    getFeatures() {
        return this.http.get(this.baseUrl + 'feature');
    }

    formatDate(date: any) {
        return moment(date).format('yyyy-MM-DD')
    }
}