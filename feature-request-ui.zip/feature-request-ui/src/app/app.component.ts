import { Component } from '@angular/core';
import { AppService } from './app.service';
import { Feature } from './feature.model';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.less']
})
export class AppComponent {
  title: string = 'Feature Request';

  featureTitle: string;
  description: string;
  client: string;
  clientPriority: number;
  targetDate: Date;
  productArea: string;

  features: Feature[] = [];
  displayedColumns: string[] = ['title', 'description', 'client', 'priority', 'targetDate', 'productArea'];

  constructor(private appService: AppService) {
    this.getFeatures();
  }

  saveFeature() {
    if (this.featureTitle && this.client && this.clientPriority) {
      this.appService.saveFeature(this.featureTitle, this.description, 
        this.client, this.clientPriority, this.targetDate, this.productArea).subscribe((data:Feature) => {
          this.features.push(data);
          this.features = [...this.features];
        });
    } else {
      console.log('Could not save feature as mandatory fields are not set.');
    }
  } 

  getFeatures() {
    this.appService.getFeatures().subscribe((data: Feature[]) => {
      this.features = data;
    });
  }

  formatDate(date: string) {
    return this.appService.formatDate(date);
  }

}
