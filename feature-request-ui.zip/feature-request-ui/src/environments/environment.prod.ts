export const environment = {
  production: true,
  backendUrl: 'http://localhost:8070'
};
