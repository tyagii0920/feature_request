#New Features
This is a web application that allows the user to manage "feature requests".

## Application Modules
1) feature-request  // Backend
2) feature-request-ui   // UI
 
## feature-request
1) Maven build the project
 
	mvn -U clean install

2) Run the application as spring boot application
3) Services defined in application are exposed in swagger,

   http://localhost:8070/swagger-ui.html
   
4) App uses in memory database, h2,

   - Launch following url for h2 client, http://localhost:8070/h2-console and fill in below details,
   - Driver Class : org.h2.Driver
   - Jdbc Url : jdbc:h2:mem:featuredb
   - Username : dbuser
   - Password : dbpassword
   
## feature-request-ui

1) Clone feature request UI
2) Build the Angular project

	>npm install

3) Run app with following command

	> ng serve   
     
4) Access the application with following url

   http://localhost:4200