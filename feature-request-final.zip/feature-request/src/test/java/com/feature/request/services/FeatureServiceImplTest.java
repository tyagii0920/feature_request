package com.feature.request.services;

import static org.mockito.ArgumentMatchers.anyList;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.junit.Before;
import org.junit.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.feature.request.dao.FeatureDao;
import com.feature.request.entities.Feature;

public class FeatureServiceImplTest {

	@InjectMocks
	private FeatureServiceImpl featureServiceImpl;

	@Mock
	private FeatureDao featureDao;
	
	@Before
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void testSaveNewFeature() {
		when(featureDao.getFeature("Client1", 1l)).thenReturn(null);
		Feature feature = getSampleFeature();
		featureServiceImpl.saveFeature(feature);
		verify(featureDao).saveFeature(feature);
	}
	
	@Test
	public void testSaveFeatureWithExistingClientPriority() {
		Feature existingFeature = getSampleFeature();
		existingFeature.setTitle("Existing Title");
		when(featureDao.getFeature("Client1", 1l)).thenReturn(existingFeature);
		List<Feature> features = Stream.of(existingFeature).collect(Collectors.toList());
		when(featureDao.getFeatures("Client1")).thenReturn(features);
		when(featureDao.saveFeatures(features)).thenReturn(features);
		Feature feature = getSampleFeature();
		when(featureDao.saveFeatures(anyList())).thenReturn(Stream.of(feature).collect(Collectors.toList()));
		featureServiceImpl.saveFeature(feature);
		verify(featureDao).saveFeatures(anyList());
	}
	
	private Feature getSampleFeature() {
		Feature feature = new Feature();
		feature.setClient("Client1");
		feature.setDescription("Sample Description");
		feature.setPriority(1l);
		feature.setProductArea("Billing");
		feature.setTargetDate(new Date());
		feature.setTitle("Title");
		return feature;
	}
	
}
