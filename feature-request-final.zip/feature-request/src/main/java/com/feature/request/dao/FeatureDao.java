package com.feature.request.dao;

import java.util.List;

import com.feature.request.entities.Feature;

public interface FeatureDao {

	Feature saveFeature(Feature feature);
	
	List<Feature> saveFeatures(List<Feature> features);
	
	List<Feature> getFeatures();
	
	Feature getFeature(String client, long priority);
	
	List<Feature> getFeatures(String client);
}
