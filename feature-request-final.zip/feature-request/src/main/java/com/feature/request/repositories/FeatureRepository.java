package com.feature.request.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.feature.request.entities.Feature;

public interface FeatureRepository extends CrudRepository<Feature, Long>{

	@Query("FROM Feature f WHERE f.client = :client order by f.priority")
	List<Feature> getFeatures(String client);

	@Query("FROM Feature f WHERE f.client = :client AND f.priority = :priority")
	Feature getFeature(String client, long priority);
}
