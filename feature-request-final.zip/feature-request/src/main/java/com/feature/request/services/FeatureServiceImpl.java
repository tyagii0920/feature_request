package com.feature.request.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feature.request.dao.FeatureDao;
import com.feature.request.entities.Feature;

@Service
public class FeatureServiceImpl implements FeatureService {

	@Autowired
	private FeatureDao featureDao;

	@Override
	public Feature saveFeature(Feature feature) {
		if (isClientWithPriorityExists(feature)) {
			final List<Feature> featuresToUpdate = new ArrayList<>();
			featuresToUpdate.add(feature);
			changeExistingFeaturePriority(feature, featuresToUpdate);
			return saveFeatures(feature, featuresToUpdate);
		} else {
			return featureDao.saveFeature(feature);
		}
	}

	@Override
	public List<Feature> getFeatures() {
		return featureDao.getFeatures();
	}

	private boolean isClientWithPriorityExists(Feature feature) {
		return null != featureDao.getFeature(feature.getClient(), feature.getPriority());
	}

	private Feature saveFeatures(Feature feature, final List<Feature> featuresToUpdate) {
		List<Feature> features = featureDao.saveFeatures(featuresToUpdate);
		return getSavedNewFeature(feature, features);
	}

	private Feature getSavedNewFeature(Feature feature, List<Feature> features) {
		return features.stream().filter(featureItr -> feature.getPriority() == featureItr.getPriority()).findFirst()
				.get();
	}

	private void changeExistingFeaturePriority(Feature feature, final List<Feature> featuresToUpdate) {
		featureDao.getFeatures(feature.getClient()).forEach(featureItr -> {
			if (featureItr.getPriority() >= feature.getPriority()) {
				featureItr.setPriority(featureItr.getPriority() + 1);
				featuresToUpdate.add(featureItr);
			}
		});
	}
}
