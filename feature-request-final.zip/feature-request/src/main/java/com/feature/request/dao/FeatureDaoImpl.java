package com.feature.request.dao;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.feature.request.entities.Feature;
import com.feature.request.repositories.FeatureRepository;

@Service
@Transactional
public class FeatureDaoImpl implements FeatureDao {

	@Autowired
	private FeatureRepository featureRepository;

	@Override
	public Feature saveFeature(Feature feature) {
		return featureRepository.save(feature);
	}
	
	@Override
	public List<Feature> saveFeatures(List<Feature> features) {
		List<Feature> savedFeatures = new ArrayList<>();
		featureRepository.saveAll(features).forEach(savedFeatures::add);
		return savedFeatures;
	}

	@Override
	public List<Feature> getFeatures() {
		List<Feature> features = new ArrayList<>();
		featureRepository.findAll().forEach(features::add);
		return features;
	}

	@Override
	public Feature getFeature(String client, long priority) {
		return featureRepository.getFeature(client, priority);
	}

	@Override
	public List<Feature> getFeatures(String client) {
		return featureRepository.getFeatures(client);
	}

}
