package com.feature.request.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.feature.request.entities.Feature;
import com.feature.request.services.FeatureService;

@CrossOrigin
@RestController
@RequestMapping("/feature")
public class FeatureController {

	@Autowired
	private FeatureService featureService;

	@PostMapping
	public ResponseEntity<Feature> save(@RequestParam(required = true) String title, 
			@RequestParam(required = false) String description, @RequestParam(required = true) String client, 
			@RequestParam(required = true) long priority,
			@RequestParam(name = "targetDate", required = false) @DateTimeFormat(iso = ISO.DATE) Date targetDate, 
			@RequestParam(required = false) String productArea) {
		Feature feature = new Feature();
		feature.setTitle(title);
		feature.setDescription(description);
		feature.setClient(client);
		feature.setPriority(priority);
		feature.setTargetDate(targetDate);
		feature.setProductArea(productArea);
		return new ResponseEntity<Feature>(featureService.saveFeature(feature), HttpStatus.OK);
	}

	@GetMapping
	public ResponseEntity<List<Feature>> getFeatures() {
		return new ResponseEntity<List<Feature>>(featureService.getFeatures(), HttpStatus.OK);
	}

}
