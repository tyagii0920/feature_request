package com.feature.request.services;

import java.util.List;

import com.feature.request.entities.Feature;

public interface FeatureService {
	
	public Feature saveFeature(Feature feature);
	
	List<Feature> getFeatures();

}
