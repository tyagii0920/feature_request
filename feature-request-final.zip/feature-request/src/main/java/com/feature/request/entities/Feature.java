package com.feature.request.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.Table;

import lombok.Data;

@Entity
@Table(name = "FEATURE", indexes = { @Index(name = "FEATURE_CLIENT_INDEX", columnList = "CLIENT", unique = false) })
@Data
public class Feature implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -7236601038073922665L;

	@Id
	@GeneratedValue
	private long id;

	@Column(name = "TITLE")
	private String title;

	@Column(name = "DESCRIPTION")
	private String description;

	@Column(name = "CLIENT")
	private String client;

	@Column(name = "PRIORITY")
	private long priority;

	@Column(name = "TARGET_DATE")
	private Date targetDate;

	@Column(name = "PRODUCT_AREA")
	private String productArea;

}
